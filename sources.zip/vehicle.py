class Vehicle:
    def __init__(self, rides=None):
        self.rides = rides
